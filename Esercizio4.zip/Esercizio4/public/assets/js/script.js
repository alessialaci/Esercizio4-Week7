var dati;
var errore;
var elenco = [];

window.addEventListener('DOMContentLoaded', init());

function init() {
    errore = document.getElementById('errore');
    dati = document.getElementById('dati');
    printData();
}

function printData() {
    fetch('https://jsonplaceholder.typicode.com/users').then((response) => {
        return response.json();
    }).then((data) => {
        elenco = data;
        if (elenco.length > 0) {
            errore.innerHTML = '';
            dati.innerHTML = '';
            elenco.map(function(element) {
                dati.innerHTML += `<td>${element.name}</td>
                <td>${element.username}</td>
                <td>${element.email}</td>
                <td>${element.address.street}, ${element.address.suite} - ${element.address.city} - ${element.address.zipcode}</td>`
            });
        }
    });
}

async function addData(data) {
    let response = await fetch('https://jsonplaceholder.typicode.com/users', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=utf-8',
        },
        body: JSON.stringify(data),
    });
}